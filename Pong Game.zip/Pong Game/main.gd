extends Sprite2D

var score := [0, 0] # Khai bao diem ban dau la 0-0 
# 0: Nguoi choi; 1: CPU
const PADDLE_SPEED : int = 500 # chinh toc do di chuyen cua van tai day

# 1. Khai báo biến trạng thái game
var is_game_over := false

func _ready() -> void:
	# Đảm bảo lúc mới vào game, chữ phân định thắng thua ở giữa màn hình được ẩn đi
	# Mình giả định bạn sẽ tạo một Node tên là "ResultLabel" nằm trong "Heads-up Display" ở Bước phụ bên dưới
	$"Heads-up Display/ResultLabel".text = ""

func _on_ball_timer_timeout() -> void:
	# Nếu game đã kết thúc thì không sinh ra bóng mới nữa
	if is_game_over: return
	$Ball.new_ball()

func _on_score_left_body_entered(body: Node2D) -> void:
	if is_game_over: return # Khóa không cho cộng điểm nếu đã có người thắng
	
	score[1] += 1
	$"Heads-up Display/CPUScore".text = str(score[1])
	
	# Kiểm tra xem CPU đã thắng chưa trước khi cho chạy tiếp Timer
	if score[1] >= 7:
		declare_winner("CPU WINS!")
	else:
		$BallTimer.start()

func _on_score_right_body_entered(body: Node2D) -> void:
	if is_game_over: return # Khóa không cho cộng điểm nếu đã có người thắng
	
	score[0] += 1
	$"Heads-up Display/PlayerScore".text = str(score[0])
	
	# Kiểm tra xem Người chơi đã thắng chưa trước khi cho chạy tiếp Timer
	if score[0] >= 7:
		declare_winner("YOU WIN!")
	else:
		$BallTimer.start()

# 2. Hàm xử lý khi trò chơi kết thúc
# Hàm xử lý khi trò chơi kết thúc (Thay thế hàm cũ của bạn)
func declare_winner(winner_text: String) -> void:
	is_game_over = true
	$BallTimer.stop() # Dừng timer đếm giây
	
	var result_label := $"Heads-up Display/ResultLabel"
	result_label.text = winner_text
	
	# Sử dụng cấu trúc rẽ nhánh để định vị chữ theo phe thắng cuộc
	if winner_text == "BẠN ĐÃ THẮNG!":
		# Đẩy chữ sang nửa bên TRÁI màn hình
		result_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN # Chữ dài ra hướng về bên trái
		result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT # Căn lề phải của khối chữ
		# Neo gốc chữ vào vị trí 40% chiều ngang màn hình (né vạch trắng ở giữa 50%)
		result_label.anchor_left = 0.4
		result_label.anchor_right = 0.4
	else:
		# Đẩy chữ sang nửa bên PHẢI màn hình
		result_label.grow_horizontal = Control.GROW_DIRECTION_END # Chữ dài ra hướng về bên phải
		result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT # Căn lề trái của khối chữ
		# Neo gốc chữ vào vị trí 60% chiều ngang màn hình
		result_label.anchor_left = 0.6
		result_label.anchor_right = 0.6

	# Xóa quả bóng hiện tại đi để gameplay dừng hoàn toàn
	if has_node("Ball"):
		$Ball.queue_free()
