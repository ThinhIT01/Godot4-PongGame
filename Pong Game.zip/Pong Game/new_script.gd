extends CharacterBody2D

# Tốc độ di chuyển của nhân vật (pixel trên giây)
@export var speed: float = 300.0

func _physics_process(delta: float) -> void:
	# 1. Lấy hướng di chuyển từ bàn phím dựa trên Input Map đã cài đặt
	var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	
	# 2. Nếu có bấm phím (direction khác 0), tính vận tốc dựa trên hướng và tốc độ
	if direction != Vector2.ZERO:
		velocity = direction * speed
	else:
		# Nếu thả tay ra, nhân vật sẽ dừng lại ngay lập tức
		velocity = Vector2.ZERO

	# 3. Hàm có sẵn của Godot để tự động di chuyển nhân vật và xử lý nếu đập vào tường
	move_and_slide()
